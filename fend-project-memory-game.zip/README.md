# Memory Game Project

## Table of Contents

* [Introduction](#introduction)
* [Rules](#rules)
* [Dependencies](#dependencies)

## Introduction
This is a little memory game, created in the Udacity Front end web developer nanodegree.
## Rules
You have to open a card by clicking on it. Now you have to find the matching card. If you are successfull the matching cards will stay opened, otherways the'll turn back around.


The goal is to find all matching cards with as least as possible turns.

## Dependencies
* Font awesome https://fontawesome.com/
* jQuery https://jquery.com/
* jQuery UI https://jqueryui.com/




